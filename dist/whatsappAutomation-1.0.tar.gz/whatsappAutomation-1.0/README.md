# WhatsappBOT
It's an automated whatsapp bot which can serve as chatbot and can perform search operations on google, youtube, wikipedia 

It can automatically fetch for new messages and reply to the user.

Libraries used - 
Chatterbot - For chatBot
Selenium - for controling browser and scrapping and sending messages
os - to run existing chrome session


