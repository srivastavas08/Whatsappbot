from setuptools import setup

setup(
    name = 'whatsappAutomation',
    version = '1.00',
    packages = ['whatsapp'],
    url = '',
    license = '',
    author = 'KIRAN CHANDRA',
    author_email = 'srivastavas08@gmail.com',
    description = 'It\'s a whatsapp Automation BOT which fetch a message and reply on its own.'
)
